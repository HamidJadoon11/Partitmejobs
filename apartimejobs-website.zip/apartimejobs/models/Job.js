import mongoose from 'mongoose'

const JobSchema = new mongoose.Schema({
  title: { type: String, required: true, index: true },
  company: { type: String, required: true },
  companyLogo: { type: String, default: '' },
  location: { type: String, default: 'Remote' },
  jobType: {
    type: String,
    enum: ['full_time', 'part_time', 'contract', 'freelance', 'internship'],
    default: 'full_time',
  },
  category: { type: String, required: true, index: true },
  salary: { type: String, default: '' },
  description: { type: String, required: true },
  applyUrl: { type: String, required: true },
  tags: [{ type: String }],
  slug: { type: String, unique: true, required: true, index: true },
  source: { type: String, default: 'manual' },
  externalId: { type: String, unique: true, sparse: true },
  isRemote: { type: Boolean, default: true },
  isFeatured: { type: Boolean, default: false },
  isActive: { type: Boolean, default: true },
  views: { type: Number, default: 0 },
  postedAt: { type: Date, default: Date.now, index: true },
  expiresAt: {
    type: Date,
    default: () => new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
  },
}, {
  timestamps: true,
})

// Text search index
JobSchema.index({ title: 'text', company: 'text', description: 'text', tags: 'text' })

// Auto-expire old jobs
JobSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 })

export default mongoose.models.Job || mongoose.model('Job', JobSchema)
