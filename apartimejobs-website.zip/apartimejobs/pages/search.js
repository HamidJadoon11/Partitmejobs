import { useState } from 'react'
import { useRouter } from 'next/router'
import Layout from '../components/Layout'
import JobCard from '../components/JobCard'
import connectDB from '../lib/mongodb'
import Job from '../models/Job'
import { CATEGORIES } from '../lib/fetchJobs'

const JOB_TYPES = [
  { value: '', label: 'All Types' },
  { value: 'full_time', label: 'Full-time' },
  { value: 'part_time', label: 'Part-time' },
  { value: 'contract', label: 'Contract' },
  { value: 'freelance', label: 'Freelance' },
  { value: 'internship', label: 'Internship' },
]

export default function SearchPage({ jobs, total, query, type, category, page }) {
  const router = useRouter()
  const [searchInput, setSearchInput] = useState(query || '')
  const totalPages = Math.ceil(total / 20)
  const getCatSlug = (cat) =>
    cat.toLowerCase().replace(/\s+&\s+/g, '-').replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')

  const applyFilter = (params) => {
    const current = { q: query || '', type: type || '', category: category || '', page: 1 }
    const merged = { ...current, ...params }
    const queryStr = Object.entries(merged)
      .filter(([, v]) => v)
      .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
      .join('&')
    router.push(`/search?${queryStr}`)
  }

  const handleSearch = (e) => {
    e.preventDefault()
    applyFilter({ q: searchInput, page: 1 })
  }

  return (
    <Layout
      title={query ? `${query} — Remote Jobs` : 'All Remote Part-Time Jobs'}
      description={`Browse ${total} remote jobs${query ? ` for "${query}"` : ''}. Filter by type, category, and more.`}
      canonical="/search"
    >
      {/* Search Header */}
      <div className="bg-navy-800 py-8 px-4">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSearch}>
            <div className="flex gap-2 bg-white rounded-xl p-2">
              <div className="flex-1 flex items-center gap-3 px-3">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className="text-slate-400">
                  <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="2"/>
                  <path d="m21 21-4.35-4.35" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                </svg>
                <input
                  type="text"
                  value={searchInput}
                  onChange={e => setSearchInput(e.target.value)}
                  placeholder="Job title, skill, or keyword..."
                  className="flex-1 text-slate-700 text-sm outline-none placeholder:text-slate-400"
                />
                {searchInput && (
                  <button type="button" onClick={() => { setSearchInput(''); applyFilter({ q: '' }) }}
                    className="text-slate-400 hover:text-slate-600">✕</button>
                )}
              </div>
              <button type="submit" className="btn-primary">Search</button>
            </div>
          </form>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          <aside className="lg:w-64 flex-shrink-0">
            {/* Job Type */}
            <div className="card p-5 mb-4">
              <h3 className="font-semibold text-navy-800 text-sm mb-3">Job Type</h3>
              <div className="space-y-2">
                {JOB_TYPES.map(t => (
                  <label key={t.value} className="flex items-center gap-2 cursor-pointer group">
                    <input
                      type="radio"
                      name="jobType"
                      checked={type === t.value}
                      onChange={() => applyFilter({ type: t.value })}
                      className="accent-brand-500"
                    />
                    <span className={`text-sm ${type === t.value ? 'text-brand-600 font-medium' : 'text-slate-600 group-hover:text-navy-800'}`}>
                      {t.label}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {/* Category */}
            <div className="card p-5">
              <h3 className="font-semibold text-navy-800 text-sm mb-3">Category</h3>
              <div className="space-y-2 max-h-72 overflow-y-auto">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="category" checked={!category}
                    onChange={() => applyFilter({ category: '' })} className="accent-brand-500" />
                  <span className="text-sm text-slate-600">All Categories</span>
                </label>
                {CATEGORIES.map(cat => (
                  <label key={cat} className="flex items-center gap-2 cursor-pointer group">
                    <input type="radio" name="category" checked={category === cat}
                      onChange={() => applyFilter({ category: cat })} className="accent-brand-500" />
                    <span className={`text-sm leading-tight ${category === cat ? 'text-brand-600 font-medium' : 'text-slate-600'}`}>
                      {cat}
                    </span>
                  </label>
                ))}
              </div>
            </div>
          </aside>

          {/* Results */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="font-display text-xl font-bold text-navy-800">
                  {query ? `Results for "${query}"` : category || 'All Remote Jobs'}
                </h1>
                <p className="text-slate-500 text-sm mt-0.5">{total.toLocaleString()} jobs found</p>
              </div>
              {(query || type || category) && (
                <button onClick={() => router.push('/search')}
                  className="text-xs text-slate-400 hover:text-red-500 border border-slate-200 px-3 py-1.5 rounded-lg">
                  Clear filters ✕
                </button>
              )}
            </div>

            {jobs.length === 0 ? (
              <div className="card p-12 text-center">
                <div className="text-5xl mb-4">🔍</div>
                <h3 className="font-display font-bold text-navy-800 text-lg mb-2">No jobs found</h3>
                <p className="text-slate-500 text-sm">Try different keywords or remove filters</p>
              </div>
            ) : (
              <div className="grid gap-4">
                {jobs.map(job => <JobCard key={job._id} job={job} />)}
              </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-8">
                {page > 1 && (
                  <button onClick={() => applyFilter({ page: page - 1 })}
                    className="btn-outline px-4 py-2 text-sm">← Prev</button>
                )}
                <span className="text-sm text-slate-500 px-4">Page {page} of {totalPages}</span>
                {page < totalPages && (
                  <button onClick={() => applyFilter({ page: page + 1 })}
                    className="btn-outline px-4 py-2 text-sm">Next →</button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  )
}

export async function getServerSideProps({ query: qs }) {
  try {
    await connectDB()
    const searchQuery = qs.q || ''
    const type = qs.type || ''
    const category = qs.category || ''
    const page = parseInt(qs.page) || 1
    const limit = 20
    const skip = (page - 1) * limit

    const filter = { isActive: true }
    if (type) filter.jobType = type
    if (category) filter.category = category
    if (searchQuery) {
      filter.$or = [
        { title: { $regex: searchQuery, $options: 'i' } },
        { company: { $regex: searchQuery, $options: 'i' } },
        { tags: { $in: [new RegExp(searchQuery, 'i')] } },
      ]
    }

    const [jobs, total] = await Promise.all([
      Job.find(filter).sort({ isFeatured: -1, postedAt: -1 }).skip(skip).limit(limit).lean(),
      Job.countDocuments(filter),
    ])

    return {
      props: {
        jobs: JSON.parse(JSON.stringify(jobs)),
        total, query: searchQuery, type, category, page,
      },
    }
  } catch (err) {
    return { props: { jobs: [], total: 0, query: '', type: '', category: '', page: 1 } }
  }
}
