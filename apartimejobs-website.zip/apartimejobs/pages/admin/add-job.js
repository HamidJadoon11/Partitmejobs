import { useState } from 'react'
import { useRouter } from 'next/router'
import Head from 'next/head'
import Link from 'next/link'
import { CATEGORIES } from '../../lib/fetchJobs'

const JOB_TYPES = ['full_time', 'part_time', 'contract', 'freelance', 'internship']

export default function AddJob() {
  const router = useRouter()
  const [form, setForm] = useState({
    title: '', company: '', companyLogo: '', location: 'Remote',
    jobType: 'part_time', category: CATEGORIES[0], salary: '',
    description: '', applyUrl: '', tags: '', isRemote: true, isFeatured: false,
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const set = (key, value) => setForm(f => ({ ...f, [key]: value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.title || !form.company || !form.description || !form.applyUrl) {
      setError('Please fill in all required fields.')
      return
    }
    setLoading(true)
    setError('')
    try {
      const payload = {
        ...form,
        tags: form.tags.split(',').map(t => t.trim()).filter(Boolean),
      }
      const res = await fetch('/api/admin/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (res.ok) {
        router.push('/admin/jobs')
      } else {
        const d = await res.json()
        setError(d.error || 'Failed to add job')
      }
    } catch (err) {
      setError(err.message)
    }
    setLoading(false)
  }

  return (
    <>
      <Head><title>Add Job — Admin</title></Head>
      <div className="min-h-screen bg-slate-50">
        <div className="bg-navy-800 border-b border-navy-700 px-6 py-4 flex items-center gap-4">
          <Link href="/admin/dashboard" className="font-display font-bold text-white text-lg">
            aParttime<span className="text-brand-400">Jobs</span>
            <span className="text-slate-400 text-sm font-sans font-normal ml-2">Admin</span>
          </Link>
          <nav className="flex gap-1">
            <Link href="/admin/dashboard" className="text-sm text-slate-300 hover:text-white hover:bg-navy-700 px-3 py-1.5 rounded-lg">Dashboard</Link>
            <Link href="/admin/jobs" className="text-sm text-slate-300 hover:text-white hover:bg-navy-700 px-3 py-1.5 rounded-lg">Jobs</Link>
            <Link href="/admin/add-job" className="text-sm text-white bg-navy-700 px-3 py-1.5 rounded-lg">+ Add Job</Link>
          </nav>
        </div>

        <div className="max-w-3xl mx-auto px-6 py-8">
          <h1 className="font-display text-2xl font-bold text-navy-800 mb-6">Add Job Manually</h1>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-xl mb-5">{error}</div>
          )}

          <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-slate-100 p-6 space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Job Title *</label>
                <input type="text" required value={form.title} onChange={e => set('title', e.target.value)}
                  placeholder="e.g. Remote React Developer"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-brand-400" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Company *</label>
                <input type="text" required value={form.company} onChange={e => set('company', e.target.value)}
                  placeholder="e.g. Acme Inc."
                  className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-brand-400" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Location</label>
                <input type="text" value={form.location} onChange={e => set('location', e.target.value)}
                  placeholder="Remote / Worldwide"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-brand-400" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Salary</label>
                <input type="text" value={form.salary} onChange={e => set('salary', e.target.value)}
                  placeholder="e.g. $50k - $80k / year"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-brand-400" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Job Type</label>
                <select value={form.jobType} onChange={e => set('jobType', e.target.value)}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-brand-400">
                  {JOB_TYPES.map(t => <option key={t} value={t}>{t.replace('_', '-')}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1.5">Category</label>
                <select value={form.category} onChange={e => set('category', e.target.value)}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-brand-400">
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Apply URL *</label>
              <input type="url" required value={form.applyUrl} onChange={e => set('applyUrl', e.target.value)}
                placeholder="https://company.com/jobs/apply"
                className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-brand-400" />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Company Logo URL</label>
              <input type="url" value={form.companyLogo} onChange={e => set('companyLogo', e.target.value)}
                placeholder="https://company.com/logo.png"
                className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-brand-400" />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Tags (comma-separated)</label>
              <input type="text" value={form.tags} onChange={e => set('tags', e.target.value)}
                placeholder="React, JavaScript, Node.js, Remote"
                className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-brand-400" />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">Job Description * (HTML allowed)</label>
              <textarea required value={form.description} onChange={e => set('description', e.target.value)}
                rows={8} placeholder="Write the full job description here..."
                className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-brand-400 resize-y" />
            </div>

            <div className="flex gap-6">
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input type="checkbox" checked={form.isRemote} onChange={e => set('isRemote', e.target.checked)} className="accent-brand-500" />
                Remote Position
              </label>
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input type="checkbox" checked={form.isFeatured} onChange={e => set('isFeatured', e.target.checked)} className="accent-brand-500" />
                Featured (shows on homepage)
              </label>
            </div>

            <div className="flex gap-3 pt-2">
              <Link href="/admin/jobs" className="btn-outline flex-1 text-center">Cancel</Link>
              <button type="submit" disabled={loading} className="btn-primary flex-1">
                {loading ? 'Adding...' : 'Add Job'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  )
}
