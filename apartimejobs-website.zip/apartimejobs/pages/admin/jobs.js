import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/router'
import Head from 'next/head'
import Link from 'next/link'
import { CATEGORIES } from '../../lib/fetchJobs'

export default function AdminJobs() {
  const router = useRouter()
  const [jobs, setJobs] = useState([])
  const [total, setTotal] = useState(0)
  const [pages, setPages] = useState(1)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterCat, setFilterCat] = useState('')
  const [filterSource, setFilterSource] = useState('')
  const [page, setPage] = useState(1)
  const [editJob, setEditJob] = useState(null)
  const [saving, setSaving] = useState(false)

  const fetchJobs = useCallback(async () => {
    setLoading(true)
    const params = new URLSearchParams({ page, search, category: filterCat, source: filterSource })
    const res = await fetch(`/api/admin/jobs?${params}`)
    if (res.status === 401) { router.push('/admin'); return }
    const data = await res.json()
    setJobs(data.jobs || [])
    setTotal(data.total || 0)
    setPages(data.pages || 1)
    setLoading(false)
  }, [page, search, filterCat, filterSource])

  useEffect(() => { fetchJobs() }, [fetchJobs])

  const toggleField = async (id, field, current) => {
    await fetch(`/api/admin/jobs/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ [field]: !current }),
    })
    setJobs(prev => prev.map(j => j._id === id ? { ...j, [field]: !current } : j))
  }

  const deleteJob = async (id) => {
    if (!confirm('Delete this job?')) return
    await fetch(`/api/admin/jobs/${id}`, { method: 'DELETE' })
    setJobs(prev => prev.filter(j => j._id !== id))
    setTotal(t => t - 1)
  }

  const saveEdit = async () => {
    setSaving(true)
    await fetch(`/api/admin/jobs/${editJob._id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(editJob),
    })
    setJobs(prev => prev.map(j => j._id === editJob._id ? editJob : j))
    setEditJob(null)
    setSaving(false)
  }

  return (
    <>
      <Head><title>Manage Jobs — Admin</title></Head>
      <div className="min-h-screen bg-slate-50">
        {/* Navbar */}
        <div className="bg-navy-800 border-b border-navy-700 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/admin/dashboard" className="font-display font-bold text-white text-lg">
              aParttime<span className="text-brand-400">Jobs</span>
              <span className="text-slate-400 text-sm font-sans font-normal ml-2">Admin</span>
            </Link>
            <nav className="flex gap-1">
              <Link href="/admin/dashboard" className="text-sm text-slate-300 hover:text-white hover:bg-navy-700 px-3 py-1.5 rounded-lg">Dashboard</Link>
              <Link href="/admin/jobs" className="text-sm text-white bg-navy-700 px-3 py-1.5 rounded-lg">Jobs</Link>
              <Link href="/admin/add-job" className="text-sm text-slate-300 hover:text-white hover:bg-navy-700 px-3 py-1.5 rounded-lg">+ Add Job</Link>
            </nav>
          </div>
          <Link href="/" target="_blank" className="text-xs text-slate-400 hover:text-white">View Site →</Link>
        </div>

        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="font-display text-2xl font-bold text-navy-800">
              All Jobs <span className="text-slate-400 font-normal text-lg">({total.toLocaleString()})</span>
            </h1>
            <Link href="/admin/add-job" className="btn-primary text-sm">+ Add Manual Job</Link>
          </div>

          {/* Filters */}
          <div className="bg-white rounded-xl border border-slate-100 p-4 mb-6 flex flex-wrap gap-3">
            <input
              type="text"
              placeholder="Search by title or company..."
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1) }}
              className="border border-slate-200 rounded-lg px-3 py-2 text-sm flex-1 min-w-48 outline-none focus:border-brand-400"
            />
            <select value={filterCat} onChange={e => { setFilterCat(e.target.value); setPage(1) }}
              className="border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-brand-400">
              <option value="">All Categories</option>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={filterSource} onChange={e => { setFilterSource(e.target.value); setPage(1) }}
              className="border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-brand-400">
              <option value="">All Sources</option>
              {['remotive', 'arbeitnow', 'jsearch', 'adzuna', 'manual'].map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          {/* Jobs Table */}
          <div className="bg-white rounded-xl border border-slate-100 overflow-hidden">
            {loading ? (
              <div className="p-12 text-center text-slate-400">Loading...</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-100 bg-slate-50">
                      <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Job</th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide hidden md:table-cell">Category</th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide hidden lg:table-cell">Source</th>
                      <th className="text-center px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Active</th>
                      <th className="text-center px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Featured</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {jobs.map(job => (
                      <tr key={job._id} className={`hover:bg-slate-50 ${!job.isActive ? 'opacity-50' : ''}`}>
                        <td className="px-4 py-3">
                          <div className="font-medium text-navy-800 line-clamp-1">{job.title}</div>
                          <div className="text-xs text-slate-500">{job.company} · {job.location}</div>
                        </td>
                        <td className="px-4 py-3 hidden md:table-cell">
                          <span className="text-xs text-slate-600">{job.category}</span>
                        </td>
                        <td className="px-4 py-3 hidden lg:table-cell">
                          <span className="badge bg-slate-100 text-slate-600 text-xs capitalize">{job.source}</span>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <button onClick={() => toggleField(job._id, 'isActive', job.isActive)}
                            className={`w-8 h-4 rounded-full transition-colors ${job.isActive ? 'bg-green-400' : 'bg-slate-200'}`}>
                          </button>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <button onClick={() => toggleField(job._id, 'isFeatured', job.isFeatured)}
                            className={`text-lg ${job.isFeatured ? 'text-amber-400' : 'text-slate-200'}`}>★</button>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Link href={`/jobs/${job.slug}`} target="_blank"
                              className="text-xs text-slate-400 hover:text-brand-500">View</Link>
                            <button onClick={() => setEditJob({ ...job })}
                              className="text-xs text-brand-500 hover:underline">Edit</button>
                            <button onClick={() => deleteJob(job._id)}
                              className="text-xs text-red-400 hover:text-red-600">Del</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Pagination */}
          {pages > 1 && (
            <div className="flex items-center justify-center gap-3 mt-6">
              {page > 1 && <button onClick={() => setPage(p => p - 1)} className="btn-outline text-sm px-4 py-2">← Prev</button>}
              <span className="text-sm text-slate-500">Page {page} of {pages}</span>
              {page < pages && <button onClick={() => setPage(p => p + 1)} className="btn-outline text-sm px-4 py-2">Next →</button>}
            </div>
          )}
        </div>

        {/* Edit Modal */}
        {editJob && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <h2 className="font-display font-bold text-navy-800">Edit Job</h2>
                <button onClick={() => setEditJob(null)} className="text-slate-400 hover:text-slate-600 text-xl">✕</button>
              </div>
              <div className="p-6 space-y-4">
                {[
                  { label: 'Title', key: 'title' },
                  { label: 'Company', key: 'company' },
                  { label: 'Location', key: 'location' },
                  { label: 'Salary', key: 'salary' },
                  { label: 'Apply URL', key: 'applyUrl' },
                ].map(field => (
                  <div key={field.key}>
                    <label className="block text-xs font-medium text-slate-500 mb-1">{field.label}</label>
                    <input type="text" value={editJob[field.key] || ''}
                      onChange={e => setEditJob(j => ({ ...j, [field.key]: e.target.value }))}
                      className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-brand-400"
                    />
                  </div>
                ))}
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Category</label>
                  <select value={editJob.category} onChange={e => setEditJob(j => ({ ...j, category: e.target.value }))}
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-brand-400">
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="checkbox" checked={editJob.isActive}
                      onChange={e => setEditJob(j => ({ ...j, isActive: e.target.checked }))} className="accent-brand-500" />
                    Active
                  </label>
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="checkbox" checked={editJob.isFeatured}
                      onChange={e => setEditJob(j => ({ ...j, isFeatured: e.target.checked }))} className="accent-brand-500" />
                    Featured
                  </label>
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="checkbox" checked={editJob.isRemote}
                      onChange={e => setEditJob(j => ({ ...j, isRemote: e.target.checked }))} className="accent-brand-500" />
                    Remote
                  </label>
                </div>
              </div>
              <div className="p-6 border-t border-slate-100 flex gap-3">
                <button onClick={() => setEditJob(null)} className="btn-outline flex-1">Cancel</button>
                <button onClick={saveEdit} disabled={saving} className="btn-primary flex-1">
                  {saving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  )
}
