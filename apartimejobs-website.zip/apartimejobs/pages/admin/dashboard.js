import { useState, useEffect } from 'react'
import { useRouter } from 'next/router'
import Head from 'next/head'
import Link from 'next/link'

function StatCard({ label, value, color = 'blue', icon }) {
  const colors = {
    blue: 'bg-blue-50 text-blue-700 border-blue-100',
    green: 'bg-green-50 text-green-700 border-green-100',
    purple: 'bg-purple-50 text-purple-700 border-purple-100',
    amber: 'bg-amber-50 text-amber-700 border-amber-100',
  }
  return (
    <div className={`rounded-xl border p-5 ${colors[color]}`}>
      <div className="text-2xl mb-1">{icon}</div>
      <div className="text-3xl font-display font-bold">{value?.toLocaleString() ?? '—'}</div>
      <div className="text-sm font-medium mt-1 opacity-80">{label}</div>
    </div>
  )
}

export default function AdminDashboard() {
  const router = useRouter()
  const [stats, setStats] = useState(null)
  const [fetching, setFetching] = useState(false)
  const [fetchResult, setFetchResult] = useState(null)

  useEffect(() => {
    fetch('/api/admin/stats')
      .then(r => { if (r.status === 401) router.push('/admin'); return r.json() })
      .then(setStats)
      .catch(() => router.push('/admin'))
  }, [])

  const triggerFetch = async () => {
    setFetching(true)
    setFetchResult(null)
    try {
      const res = await fetch(`/api/fetch-jobs?secret=${encodeURIComponent(prompt('Enter CRON_SECRET:') || '')}`)
      const data = await res.json()
      setFetchResult(data)
      // Refresh stats
      fetch('/api/admin/stats').then(r => r.json()).then(setStats)
    } catch (e) {
      setFetchResult({ error: e.message })
    }
    setFetching(false)
  }

  const logout = async () => {
    document.cookie = 'admin_token=; Max-Age=0; Path=/'
    router.push('/admin')
  }

  return (
    <>
      <Head><title>Dashboard — Admin | aParttimeJobs.us</title></Head>
      <div className="min-h-screen bg-slate-50">
        {/* Admin Navbar */}
        <div className="bg-navy-800 border-b border-navy-700 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="font-display font-bold text-white text-lg">
              aParttime<span className="text-brand-400">Jobs</span>
              <span className="text-slate-400 text-sm font-sans font-normal ml-2">Admin</span>
            </Link>
            <nav className="flex gap-1">
              {[
                { href: '/admin/dashboard', label: 'Dashboard' },
                { href: '/admin/jobs', label: 'Jobs' },
                { href: '/admin/add-job', label: '+ Add Job' },
              ].map(l => (
                <Link key={l.href} href={l.href}
                  className="text-sm text-slate-300 hover:text-white hover:bg-navy-700 px-3 py-1.5 rounded-lg transition-colors">
                  {l.label}
                </Link>
              ))}
            </nav>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/" target="_blank" className="text-xs text-slate-400 hover:text-white">
              View Site →
            </Link>
            <button onClick={logout} className="text-xs text-slate-400 hover:text-red-400 border border-navy-600 px-3 py-1.5 rounded-lg">
              Logout
            </button>
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between mb-8">
            <h1 className="font-display text-2xl font-bold text-navy-800">Dashboard</h1>
            <button
              onClick={triggerFetch}
              disabled={fetching}
              className="btn-primary flex items-center gap-2 text-sm"
            >
              {fetching ? (
                <><span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span> Fetching...</>
              ) : (
                <><span>🔄</span> Fetch New Jobs Now</>
              )}
            </button>
          </div>

          {fetchResult && (
            <div className={`mb-6 p-4 rounded-xl text-sm ${fetchResult.error ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-green-50 text-green-700 border border-green-200'}`}>
              {fetchResult.error
                ? `Error: ${fetchResult.error}`
                : `✅ Done! Added: ${fetchResult.added} | Skipped: ${fetchResult.skipped} | Deleted old: ${fetchResult.deleted}`
              }
            </div>
          )}

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <StatCard label="Total Jobs" value={stats?.total} color="blue" icon="💼" />
            <StatCard label="Active Jobs" value={stats?.active} color="green" icon="✅" />
            <StatCard label="Featured" value={stats?.featured} color="purple" icon="⭐" />
            <StatCard label="Added Today" value={stats?.today} color="amber" icon="🆕" />
          </div>

          {/* Charts row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* By Category */}
            <div className="bg-white rounded-xl border border-slate-100 p-5">
              <h3 className="font-semibold text-navy-800 mb-4">Jobs by Category</h3>
              <div className="space-y-2">
                {stats?.byCategory?.slice(0, 8).map(item => {
                  const pct = stats?.total ? Math.round((item.count / stats.total) * 100) : 0
                  return (
                    <div key={item._id}>
                      <div className="flex justify-between text-xs text-slate-600 mb-1">
                        <span className="truncate">{item._id}</span>
                        <span className="font-medium ml-2">{item.count}</span>
                      </div>
                      <div className="h-1.5 bg-slate-100 rounded-full">
                        <div className="h-1.5 bg-brand-500 rounded-full" style={{ width: `${pct}%` }}></div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* By Source */}
            <div className="bg-white rounded-xl border border-slate-100 p-5">
              <h3 className="font-semibold text-navy-800 mb-4">Jobs by Source</h3>
              <div className="space-y-3">
                {stats?.bySources?.map(item => {
                  const colors = { remotive: 'bg-green-500', arbeitnow: 'bg-blue-500', jsearch: 'bg-purple-500', adzuna: 'bg-amber-500', manual: 'bg-slate-500' }
                  const pct = stats?.total ? Math.round((item.count / stats.total) * 100) : 0
                  return (
                    <div key={item._id} className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${colors[item._id] || 'bg-slate-400'}`}></div>
                      <span className="text-sm text-slate-600 flex-1 capitalize">{item._id}</span>
                      <span className="text-sm font-medium text-navy-800">{item.count}</span>
                      <span className="text-xs text-slate-400 w-8 text-right">{pct}%</span>
                    </div>
                  )
                })}
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100">
                <h4 className="text-xs font-semibold text-slate-500 mb-3">QUICK ACTIONS</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Link href="/admin/jobs" className="btn-outline text-xs text-center py-2">Manage Jobs</Link>
                  <Link href="/admin/add-job" className="btn-primary text-xs text-center py-2">Add Manual Job</Link>
                </div>
              </div>
            </div>
          </div>

          {/* Cron Setup Info */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-5">
            <h3 className="font-semibold text-amber-800 mb-2">🕐 Auto-fetch Setup (cron-job.org)</h3>
            <p className="text-sm text-amber-700 mb-3">
              Set up a free cron job at <strong>cron-job.org</strong> to automatically fetch new jobs every hour.
            </p>
            <div className="bg-white rounded-lg p-3 font-mono text-xs text-slate-700 break-all">
              {typeof window !== 'undefined' ? window.location.origin : 'https://www.apartimejobs.us'}/api/fetch-jobs?secret=YOUR_CRON_SECRET
            </div>
            <p className="text-xs text-amber-600 mt-2">
              Add header: <code className="bg-amber-100 px-1 rounded">x-cron-secret: YOUR_CRON_SECRET</code> — Schedule: every 60 minutes
            </p>
          </div>
        </div>
      </div>
    </>
  )
}
