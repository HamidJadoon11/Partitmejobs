import connectDB from '../../lib/mongodb'
import Job from '../../models/Job'
import { fetchAllJobs, generateSlug } from '../../lib/fetchJobs'

export default async function handler(req, res) {
  // Only allow GET with correct secret (from cron-job.org)
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' })

  const secret = req.headers['x-cron-secret'] || req.query.secret
  if (secret !== process.env.CRON_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  try {
    await connectDB()
    const allJobs = await fetchAllJobs()

    let added = 0
    let skipped = 0
    let errors = 0

    for (const jobData of allJobs) {
      try {
        // Skip if already exists
        if (jobData.externalId) {
          const exists = await Job.findOne({ externalId: jobData.externalId })
          if (exists) { skipped++; continue }
        }

        // Generate unique slug
        const slug = generateSlug(jobData.title, jobData.company)

        await Job.create({ ...jobData, slug })
        added++
      } catch (err) {
        if (err.code === 11000) { skipped++ } // duplicate key
        else { errors++; console.error('Save error:', err.message) }
      }
    }

    // Clean up jobs older than 30 days
    const deleted = await Job.deleteMany({
      expiresAt: { $lt: new Date() },
      isFeatured: false,
    })

    console.log(`✅ Cron done: ${added} added, ${skipped} skipped, ${errors} errors, ${deleted.deletedCount} deleted`)

    return res.status(200).json({
      success: true,
      added, skipped, errors,
      deleted: deleted.deletedCount,
      total: allJobs.length,
      timestamp: new Date().toISOString(),
    })
  } catch (err) {
    console.error('Fetch jobs error:', err)
    return res.status(500).json({ error: err.message })
  }
}
