import connectDB from '../../lib/mongodb'
import Job from '../../models/Job'
import { CATEGORIES } from '../../lib/fetchJobs'

export default async function handler(req, res) {
  try {
    await connectDB()
    const jobs = await Job.find({ isActive: true }, 'slug updatedAt').sort({ updatedAt: -1 }).limit(5000).lean()

    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://www.apartimejobs.us'
    const getCatSlug = (cat) => cat.toLowerCase().replace(/\s+&\s+/g, '-').replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
    const now = new Date().toISOString()

    const urls = [
      `<url><loc>${siteUrl}</loc><lastmod>${now}</lastmod><changefreq>hourly</changefreq><priority>1.0</priority></url>`,
      `<url><loc>${siteUrl}/search</loc><lastmod>${now}</lastmod><changefreq>hourly</changefreq><priority>0.9</priority></url>`,
      ...CATEGORIES.map(cat => `<url><loc>${siteUrl}/category/${getCatSlug(cat)}</loc><lastmod>${now}</lastmod><changefreq>hourly</changefreq><priority>0.8</priority></url>`),
      ...jobs.map(job => `<url><loc>${siteUrl}/jobs/${job.slug}</loc><lastmod>${new Date(job.updatedAt || Date.now()).toISOString()}</lastmod><changefreq>weekly</changefreq><priority>0.6</priority></url>`),
    ]

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.join('\n')}
</urlset>`

    res.setHeader('Content-Type', 'application/xml')
    res.setHeader('Cache-Control', 's-maxage=3600, stale-while-revalidate')
    res.status(200).send(xml)
  } catch (err) {
    res.status(500).send('Error generating sitemap')
  }
}
