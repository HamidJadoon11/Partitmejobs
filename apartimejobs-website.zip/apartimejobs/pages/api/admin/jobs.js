import connectDB from '../../../lib/mongodb'
import Job from '../../../models/Job'
import { verifyAdmin } from '../../../lib/auth'

export default async function handler(req, res) {
  const auth = verifyAdmin(req)
  if (!auth) return res.status(401).json({ error: 'Unauthorized' })

  await connectDB()

  if (req.method === 'GET') {
    const { page = 1, search = '', category = '', source = '', active = '' } = req.query
    const limit = 25
    const skip = (parseInt(page) - 1) * limit

    const filter = {}
    if (search) filter.$or = [
      { title: { $regex: search, $options: 'i' } },
      { company: { $regex: search, $options: 'i' } },
    ]
    if (category) filter.category = category
    if (source) filter.source = source
    if (active === 'true') filter.isActive = true
    if (active === 'false') filter.isActive = false

    const [jobs, total] = await Promise.all([
      Job.find(filter).sort({ postedAt: -1 }).skip(skip).limit(limit).lean(),
      Job.countDocuments(filter),
    ])

    return res.status(200).json({ jobs, total, page: parseInt(page), pages: Math.ceil(total / limit) })
  }

  if (req.method === 'POST') {
    const { generateSlug } = await import('../../../lib/fetchJobs')
    const slug = generateSlug(req.body.title, req.body.company)
    const job = await Job.create({ ...req.body, slug, source: 'manual' })
    return res.status(201).json(job)
  }

  res.status(405).json({ error: 'Method not allowed' })
}
