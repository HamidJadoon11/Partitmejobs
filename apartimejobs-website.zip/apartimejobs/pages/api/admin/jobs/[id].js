import connectDB from '../../../lib/mongodb'
import Job from '../../../models/Job'
import { verifyAdmin } from '../../../lib/auth'

export default async function handler(req, res) {
  const auth = verifyAdmin(req)
  if (!auth) return res.status(401).json({ error: 'Unauthorized' })

  await connectDB()
  const { id } = req.query

  if (req.method === 'PUT') {
    const job = await Job.findByIdAndUpdate(id, req.body, { new: true })
    return res.status(200).json(job)
  }

  if (req.method === 'DELETE') {
    await Job.findByIdAndDelete(id)
    return res.status(200).json({ success: true })
  }

  res.status(405).json({ error: 'Method not allowed' })
}
