import connectDB from '../../../lib/mongodb'
import Job from '../../../models/Job'
import { verifyAdmin } from '../../../lib/auth'

export default async function handler(req, res) {
  const auth = verifyAdmin(req)
  if (!auth) return res.status(401).json({ error: 'Unauthorized' })

  await connectDB()

  const [total, active, featured, today, byCategory, bySources] = await Promise.all([
    Job.countDocuments({}),
    Job.countDocuments({ isActive: true }),
    Job.countDocuments({ isFeatured: true }),
    Job.countDocuments({ postedAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } }),
    Job.aggregate([{ $group: { _id: '$category', count: { $sum: 1 } } }, { $sort: { count: -1 } }]),
    Job.aggregate([{ $group: { _id: '$source', count: { $sum: 1 } } }, { $sort: { count: -1 } }]),
  ])

  return res.status(200).json({ total, active, featured, today, byCategory, bySources })
}
