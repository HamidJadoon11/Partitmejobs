export default function handler(req, res) {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://www.apartimejobs.us'
  res.setHeader('Content-Type', 'text/plain')
  res.status(200).send(`User-agent: *
Allow: /
Disallow: /admin/
Disallow: /api/admin/

Sitemap: ${siteUrl}/api/sitemap
`)
}
