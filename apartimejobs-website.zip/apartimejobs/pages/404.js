import Link from 'next/link'
import Layout from '../components/Layout'

export default function Custom404() {
  return (
    <Layout title="Page Not Found">
      <div className="max-w-xl mx-auto px-4 py-24 text-center">
        <div className="font-display text-8xl font-bold text-slate-100 mb-4">404</div>
        <h1 className="font-display text-2xl font-bold text-navy-800 mb-3">Page not found</h1>
        <p className="text-slate-500 mb-8">This job listing may have expired or the URL is incorrect.</p>
        <div className="flex gap-3 justify-center">
          <Link href="/" className="btn-primary">Back to Home</Link>
          <Link href="/search" className="btn-outline">Browse Jobs</Link>
        </div>
      </div>
    </Layout>
  )
}
