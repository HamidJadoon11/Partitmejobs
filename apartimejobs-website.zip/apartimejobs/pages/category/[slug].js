import Link from 'next/link'
import Layout from '../../components/Layout'
import JobCard from '../../components/JobCard'
import connectDB from '../../lib/mongodb'
import Job from '../../models/Job'
import { CATEGORIES } from '../../lib/fetchJobs'

const SLUG_TO_CAT = {}
CATEGORIES.forEach(cat => {
  const slug = cat.toLowerCase().replace(/\s+&\s+/g, '-').replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
  SLUG_TO_CAT[slug] = cat
})

const CATEGORY_ICONS = {
  'Software Development': '💻', 'Design & Creative': '🎨', 'Marketing & SEO': '📢',
  'Customer Support': '🎧', 'Data & Analytics': '📊', 'Finance & Accounting': '💰',
  'Writing & Content': '✍️', 'Project Management': '📋', 'Sales & Business Dev': '📈',
  'HR & Recruiting': '👥', 'DevOps & Cloud': '☁️', 'Product Management': '🚀',
}

export default function CategoryPage({ jobs, total, category, page }) {
  const totalPages = Math.ceil(total / 20)
  const icon = CATEGORY_ICONS[category] || '💼'

  return (
    <Layout
      title={`${category} Remote Jobs`}
      description={`Browse ${total} remote ${category} jobs. Updated hourly with the latest opportunities worldwide.`}
      canonical={`/category/${category?.toLowerCase().replace(/\s+&\s+/g, '-').replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')}`}
    >
      {/* Header */}
      <div className="bg-navy-800 py-10 px-4">
        <div className="max-w-5xl mx-auto">
          <nav className="text-xs text-slate-400 mb-4 flex items-center gap-2">
            <Link href="/" className="hover:text-white">Home</Link>
            <span>/</span>
            <span className="text-white">{category}</span>
          </nav>
          <div className="flex items-center gap-4">
            <div className="text-5xl">{icon}</div>
            <div>
              <h1 className="font-display text-3xl font-bold text-white">{category} Jobs</h1>
              <p className="text-slate-300 mt-1">{total.toLocaleString()} remote positions available</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        {/* Other categories */}
        <div className="flex gap-2 flex-wrap mb-8">
          {CATEGORIES.filter(c => c !== category).slice(0, 6).map(cat => {
            const slug = cat.toLowerCase().replace(/\s+&\s+/g, '-').replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
            return (
              <Link key={cat} href={`/category/${slug}`}
                className="text-xs border border-slate-200 hover:border-brand-400 hover:text-brand-600 px-3 py-1.5 rounded-full transition-colors text-slate-600">
                {cat}
              </Link>
            )
          })}
        </div>

        {jobs.length === 0 ? (
          <div className="card p-12 text-center">
            <div className="text-5xl mb-4">{icon}</div>
            <h3 className="font-display font-bold text-navy-800 text-lg mb-2">No jobs yet in {category}</h3>
            <p className="text-slate-500 text-sm mb-4">Check back soon — we update hourly!</p>
            <Link href="/search" className="btn-primary inline-block">Browse All Jobs</Link>
          </div>
        ) : (
          <div className="grid gap-4">
            {jobs.map(job => <JobCard key={job._id} job={job} />)}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-3 mt-8">
            {page > 1 && (
              <Link href={`?page=${page - 1}`} className="btn-outline text-sm px-4 py-2">← Prev</Link>
            )}
            <span className="text-sm text-slate-500">Page {page} of {totalPages}</span>
            {page < totalPages && (
              <Link href={`?page=${page + 1}`} className="btn-outline text-sm px-4 py-2">Next →</Link>
            )}
          </div>
        )}
      </div>
    </Layout>
  )
}

export async function getServerSideProps({ params, query: qs }) {
  const category = SLUG_TO_CAT[params.slug]
  if (!category) return { notFound: true }

  try {
    await connectDB()
    const page = parseInt(qs.page) || 1
    const limit = 20
    const skip = (page - 1) * limit

    const [jobs, total] = await Promise.all([
      Job.find({ isActive: true, category }).sort({ isFeatured: -1, postedAt: -1 }).skip(skip).limit(limit).lean(),
      Job.countDocuments({ isActive: true, category }),
    ])

    return {
      props: {
        jobs: JSON.parse(JSON.stringify(jobs)),
        total, category, page,
      },
    }
  } catch {
    return { props: { jobs: [], total: 0, category, page: 1 } }
  }
}
