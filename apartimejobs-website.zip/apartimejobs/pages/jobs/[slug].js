import Link from 'next/link'
import { formatDistanceToNow, format } from 'date-fns'
import Layout from '../../components/Layout'
import JobCard from '../../components/JobCard'
import connectDB from '../../lib/mongodb'
import Job from '../../models/Job'

const JOB_TYPE_LABELS = {
  full_time: 'Full-time', part_time: 'Part-time',
  contract: 'Contract', freelance: 'Freelance', internship: 'Internship',
}

export default function JobDetail({ job, relatedJobs }) {
  if (!job) return <div>Job not found</div>

  const timeAgo = formatDistanceToNow(new Date(job.postedAt), { addSuffix: true })
  const postedDate = format(new Date(job.postedAt), 'MMMM d, yyyy')
  const initials = job.company?.substring(0, 2).toUpperCase() || 'JB'
  const getCatSlug = (cat) =>
    cat?.toLowerCase().replace(/\s+&\s+/g, '-').replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') || 'jobs'

  return (
    <Layout
      title={`${job.title} at ${job.company}`}
      description={`${job.title} at ${job.company}. ${job.location}. ${job.salary || 'Remote position'}. Apply now on aParttimeJobs.us`}
      canonical={`/jobs/${job.slug}`}
    >
      {/* Job Schema.org */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{
        __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "JobPosting",
          "title": job.title,
          "description": job.description,
          "datePosted": job.postedAt,
          "hiringOrganization": { "@type": "Organization", "name": job.company },
          "jobLocation": { "@type": "Place", "name": job.location },
          "employmentType": job.jobType?.toUpperCase().replace('_', '_'),
          "baseSalary": job.salary ? { "@type": "MonetaryAmount", "currency": "USD", "value": job.salary } : undefined,
        })
      }} />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        {/* Breadcrumb */}
        <nav className="text-xs text-slate-500 mb-6 flex items-center gap-2">
          <Link href="/" className="hover:text-brand-500">Home</Link>
          <span>/</span>
          <Link href={`/category/${getCatSlug(job.category)}`} className="hover:text-brand-500">{job.category}</Link>
          <span>/</span>
          <span className="text-slate-700 truncate max-w-xs">{job.title}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="card p-6 mb-6">
              {/* Header */}
              <div className="flex items-start gap-4 mb-6">
                <div className="flex-shrink-0">
                  {job.companyLogo ? (
                    <img src={job.companyLogo} alt={job.company}
                      className="w-16 h-16 rounded-xl object-contain border border-slate-100 bg-white p-1"
                      onError={(e) => { e.target.style.display='none'; e.target.nextSibling.style.display='flex' }} />
                  ) : null}
                  <div className={`w-16 h-16 rounded-xl bg-gradient-to-br from-brand-500 to-purple-600 items-center justify-center text-white font-bold text-lg ${job.companyLogo ? 'hidden' : 'flex'}`}>
                    {initials}
                  </div>
                </div>
                <div className="flex-1">
                  <h1 className="font-display text-2xl font-bold text-navy-800 leading-tight">{job.title}</h1>
                  <p className="text-slate-600 font-medium mt-1">{job.company}</p>
                </div>
              </div>

              {/* Meta Grid */}
              <div className="grid grid-cols-2 gap-3 mb-6">
                {[
                  { icon: '📍', label: 'Location', value: job.location },
                  { icon: '💼', label: 'Type', value: JOB_TYPE_LABELS[job.jobType] || job.jobType },
                  { icon: '🏷️', label: 'Category', value: job.category },
                  { icon: '📅', label: 'Posted', value: postedDate },
                  ...(job.salary ? [{ icon: '💰', label: 'Salary', value: job.salary }] : []),
                  ...(job.isRemote ? [{ icon: '🌍', label: 'Remote', value: 'Yes — Work from anywhere' }] : []),
                ].map(item => (
                  <div key={item.label} className="bg-slate-50 rounded-lg p-3">
                    <div className="text-xs text-slate-400 mb-0.5">{item.icon} {item.label}</div>
                    <div className="text-sm font-medium text-navy-800">{item.value}</div>
                  </div>
                ))}
              </div>

              {/* Tags */}
              {job.tags?.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-6">
                  {job.tags.map((tag, i) => (
                    <span key={i} className="badge bg-slate-100 text-slate-600">{tag}</span>
                  ))}
                </div>
              )}

              {/* Apply Button */}
              <a href={job.applyUrl} target="_blank" rel="noopener noreferrer"
                className="w-full btn-primary text-center block text-base py-3 rounded-xl">
                Apply for this Job →
              </a>
            </div>

            {/* Description */}
            <div className="card p-6">
              <h2 className="font-display text-xl font-bold text-navy-800 mb-4">Job Description</h2>
              <div
                className="job-description text-slate-600 text-sm leading-relaxed"
                dangerouslySetInnerHTML={{ __html: job.description }}
              />
              <div className="mt-6 pt-6 border-t border-slate-100">
                <a href={job.applyUrl} target="_blank" rel="noopener noreferrer"
                  className="btn-primary inline-flex items-center gap-2">
                  Apply Now
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <polyline points="15,3 21,3 21,9" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <line x1="10" y1="14" x2="21" y2="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  </svg>
                </a>
                <p className="text-xs text-slate-400 mt-2">You'll be redirected to {job.source} to apply</p>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="card p-5 mb-5">
              <h3 className="font-semibold text-navy-800 mb-4">Quick Apply</h3>
              <a href={job.applyUrl} target="_blank" rel="noopener noreferrer"
                className="w-full btn-primary text-center block mb-3">
                Apply Now →
              </a>
              <p className="text-xs text-center text-slate-400">Posted {timeAgo}</p>
            </div>

            {/* Related Jobs */}
            {relatedJobs.length > 0 && (
              <div>
                <h3 className="font-semibold text-navy-800 mb-3 text-sm">Similar Jobs</h3>
                <div className="grid gap-3">
                  {relatedJobs.map(j => (
                    <Link key={j._id} href={`/jobs/${j.slug}`}
                      className="card p-4 hover:border-brand-300 group">
                      <p className="text-sm font-medium text-navy-800 group-hover:text-brand-600 line-clamp-2">{j.title}</p>
                      <p className="text-xs text-slate-500 mt-1">{j.company}</p>
                      <p className="text-xs text-slate-400 mt-1">{j.location}</p>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  )
}

export async function getServerSideProps({ params }) {
  try {
    await connectDB()
    const job = await Job.findOneAndUpdate(
      { slug: params.slug, isActive: true },
      { $inc: { views: 1 } },
      { new: true }
    ).lean()

    if (!job) return { notFound: true }

    const relatedJobs = await Job.find({
      isActive: true, category: job.category, _id: { $ne: job._id },
    }).sort({ postedAt: -1 }).limit(4).lean()

    return {
      props: {
        job: JSON.parse(JSON.stringify(job)),
        relatedJobs: JSON.parse(JSON.stringify(relatedJobs)),
      },
    }
  } catch (err) {
    return { notFound: true }
  }
}
