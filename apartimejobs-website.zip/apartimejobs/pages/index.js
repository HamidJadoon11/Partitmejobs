import { useState } from 'react'
import { useRouter } from 'next/router'
import Link from 'next/link'
import Layout from '../components/Layout'
import JobCard from '../components/JobCard'
import connectDB from '../lib/mongodb'
import Job from '../models/Job'
import { CATEGORIES } from '../lib/fetchJobs'

const CATEGORY_ICONS = {
  'Software Development': '💻',
  'Design & Creative': '🎨',
  'Marketing & SEO': '📢',
  'Customer Support': '🎧',
  'Data & Analytics': '📊',
  'Finance & Accounting': '💰',
  'Writing & Content': '✍️',
  'Project Management': '📋',
  'Sales & Business Dev': '📈',
  'HR & Recruiting': '👥',
  'DevOps & Cloud': '☁️',
  'Product Management': '🚀',
}

export default function Home({ featuredJobs, latestJobs, categoryCounts, totalJobs }) {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState('')

  const handleSearch = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`)
    } else {
      router.push('/search')
    }
  }

  const getCatSlug = (cat) =>
    cat.toLowerCase().replace(/\s+&\s+/g, '-').replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')

  return (
    <Layout canonical="/">
      {/* Hero Section */}
      <section className="bg-navy-800 text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-navy-700 text-green-400 text-xs font-medium px-3 py-1.5 rounded-full mb-6 border border-navy-600">
            <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span>
            {totalJobs.toLocaleString()}+ Remote Jobs — Updated Hourly
          </div>

          <h1 className="font-display text-4xl sm:text-5xl font-bold leading-tight mb-4">
            Find Your Perfect<br />
            <span className="text-brand-400">Remote Part-Time</span> Job
          </h1>
          <p className="text-slate-300 text-lg mb-8 max-w-2xl mx-auto">
            Thousands of remote jobs from top companies. Fresh opportunities added every hour — work from anywhere in the world.
          </p>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
            <div className="flex gap-2 bg-white rounded-xl p-2 shadow-xl">
              <div className="flex-1 flex items-center gap-3 px-3">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className="text-slate-400 flex-shrink-0">
                  <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="2"/>
                  <path d="m21 21-4.35-4.35" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                </svg>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Job title, skill, or company..."
                  className="flex-1 text-slate-700 text-sm outline-none placeholder:text-slate-400 bg-transparent"
                />
              </div>
              <button type="submit" className="btn-primary whitespace-nowrap">
                Search Jobs
              </button>
            </div>
          </form>

          {/* Quick filters */}
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            {['Remote', 'Part-time', 'Freelance', 'No Experience', 'Entry Level'].map(tag => (
              <Link
                key={tag}
                href={`/search?q=${encodeURIComponent(tag)}`}
                className="text-xs text-slate-300 hover:text-white bg-navy-700 hover:bg-navy-600 px-3 py-1.5 rounded-full transition-colors border border-navy-600"
              >
                {tag}
              </Link>
            ))}
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        {/* Categories Grid */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="section-title">Browse by Category</h2>
            <Link href="/search" className="text-sm text-brand-500 hover:underline">View all →</Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {CATEGORIES.map(cat => {
              const slug = getCatSlug(cat)
              const count = categoryCounts[cat] || 0
              return (
                <Link
                  key={cat}
                  href={`/category/${slug}`}
                  className="card p-4 text-center hover:scale-105 transition-transform cursor-pointer group"
                >
                  <div className="text-2xl mb-2">{CATEGORY_ICONS[cat] || '💼'}</div>
                  <p className="text-xs font-medium text-navy-800 group-hover:text-brand-600 leading-tight">{cat}</p>
                  {count > 0 && (
                    <p className="text-xs text-slate-400 mt-1">{count} jobs</p>
                  )}
                </Link>
              )
            })}
          </div>
        </section>

        {/* Featured Jobs */}
        {featuredJobs.length > 0 && (
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="section-title">Featured Jobs</h2>
            </div>
            <div className="grid gap-4">
              {featuredJobs.map(job => (
                <JobCard key={job._id} job={job} featured />
              ))}
            </div>
          </section>
        )}

        {/* Latest Jobs */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="section-title">Latest Remote Jobs</h2>
            <Link href="/search" className="text-sm text-brand-500 hover:underline">View all {totalJobs}+ jobs →</Link>
          </div>
          <div className="grid gap-4">
            {latestJobs.map(job => (
              <JobCard key={job._id} job={job} />
            ))}
          </div>
          <div className="text-center mt-8">
            <Link href="/search" className="btn-primary inline-flex items-center gap-2">
              Load More Jobs
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M5 12h14M12 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </Link>
          </div>
        </section>

        {/* Stats Banner */}
        <section className="mt-16 bg-navy-800 text-white rounded-2xl p-8 text-center">
          <h2 className="font-display text-2xl font-bold mb-2">Why aParttimeJobs.us?</h2>
          <p className="text-slate-300 text-sm mb-8 max-w-xl mx-auto">We aggregate the best remote jobs from across the internet, so you don't have to search everywhere.</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { num: `${totalJobs}+`, label: 'Active Jobs' },
              { num: '4+', label: 'Job Sources' },
              { num: 'Every Hour', label: 'Updated' },
              { num: '12+', label: 'Categories' },
            ].map(stat => (
              <div key={stat.label}>
                <div className="font-display text-3xl font-bold text-brand-400">{stat.num}</div>
                <div className="text-slate-400 text-sm mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </Layout>
  )
}

export async function getServerSideProps() {
  try {
    await connectDB()

    const [featuredJobs, latestJobs, totalJobs, catAgg] = await Promise.all([
      Job.find({ isActive: true, isFeatured: true }).sort({ postedAt: -1 }).limit(3).lean(),
      Job.find({ isActive: true }).sort({ postedAt: -1 }).limit(20).lean(),
      Job.countDocuments({ isActive: true }),
      Job.aggregate([
        { $match: { isActive: true } },
        { $group: { _id: '$category', count: { $sum: 1 } } },
      ]),
    ])

    const categoryCounts = {}
    catAgg.forEach(item => { categoryCounts[item._id] = item.count })

    return {
      props: {
        featuredJobs: JSON.parse(JSON.stringify(featuredJobs)),
        latestJobs: JSON.parse(JSON.stringify(latestJobs)),
        totalJobs,
        categoryCounts,
      },
    }
  } catch (err) {
    console.error(err)
    return { props: { featuredJobs: [], latestJobs: [], totalJobs: 0, categoryCounts: {} } }
  }
}
