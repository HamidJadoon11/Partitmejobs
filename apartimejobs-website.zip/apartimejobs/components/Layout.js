import Head from 'next/head'
import Navbar from './Navbar'
import Footer from './Footer'

export default function Layout({ children, title, description, canonical }) {
  const siteTitle = title ? `${title} | aParttimeJobs.us` : 'aParttimeJobs.us — Remote Part-Time Jobs Updated Hourly'
  const siteDesc = description || 'Find the best remote part-time, freelance, and contract jobs. Thousands of remote jobs updated every hour from top companies worldwide.'
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://www.apartimejobs.us'
  const canonicalUrl = canonical ? `${siteUrl}${canonical}` : siteUrl

  return (
    <>
      <Head>
        <title>{siteTitle}</title>
        <meta name="description" content={siteDesc} />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="canonical" href={canonicalUrl} />

        {/* Open Graph */}
        <meta property="og:type" content="website" />
        <meta property="og:title" content={siteTitle} />
        <meta property="og:description" content={siteDesc} />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:site_name" content="aParttimeJobs.us" />

        {/* Twitter */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={siteTitle} />
        <meta name="twitter:description" content={siteDesc} />

        {/* Schema.org for job site */}
        <script type="application/ld+json" dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": "aParttimeJobs.us",
            "url": siteUrl,
            "description": siteDesc,
            "potentialAction": {
              "@type": "SearchAction",
              "target": `${siteUrl}/search?q={search_term_string}`,
              "query-input": "required name=search_term_string"
            }
          })
        }} />

        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
      </div>
    </>
  )
}
