import Link from 'next/link'
import { formatDistanceToNow } from 'date-fns'

const JOB_TYPE_LABELS = {
  full_time: { label: 'Full-time', color: 'bg-blue-50 text-blue-700' },
  part_time: { label: 'Part-time', color: 'bg-purple-50 text-purple-700' },
  contract: { label: 'Contract', color: 'bg-amber-50 text-amber-700' },
  freelance: { label: 'Freelance', color: 'bg-green-50 text-green-700' },
  internship: { label: 'Internship', color: 'bg-pink-50 text-pink-700' },
}

export default function JobCard({ job, featured = false }) {
  const typeInfo = JOB_TYPE_LABELS[job.jobType] || JOB_TYPE_LABELS.full_time
  const timeAgo = formatDistanceToNow(new Date(job.postedAt), { addSuffix: true })
  const initials = job.company?.substring(0, 2).toUpperCase() || 'JB'

  return (
    <Link href={`/jobs/${job.slug}`}>
      <div className={`job-card card p-5 cursor-pointer group ${featured ? 'border-brand-300 bg-brand-50/30' : ''}`}>
        <div className="flex items-start gap-4">
          {/* Company Logo */}
          <div className="flex-shrink-0">
            {job.companyLogo ? (
              <img
                src={job.companyLogo}
                alt={job.company}
                className="w-12 h-12 rounded-lg object-contain border border-slate-100 bg-white p-1"
                onError={(e) => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'flex' }}
              />
            ) : null}
            <div
              className={`w-12 h-12 rounded-lg bg-gradient-to-br from-brand-500 to-purple-600 items-center justify-center text-white font-bold text-sm ${job.companyLogo ? 'hidden' : 'flex'}`}
            >
              {initials}
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h3 className="font-display font-semibold text-navy-800 group-hover:text-brand-600 transition-colors text-base leading-snug line-clamp-2">
                  {job.title}
                </h3>
                <p className="text-slate-500 text-sm mt-0.5">{job.company}</p>
              </div>
              {featured && (
                <span className="badge bg-brand-100 text-brand-700 flex-shrink-0 text-xs">Featured</span>
              )}
            </div>

            {/* Meta */}
            <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
              {/* Location */}
              <span className="flex items-center gap-1 text-slate-500">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" fill="currentColor"/>
                </svg>
                {job.location}
              </span>

              {/* Remote badge */}
              {job.isRemote && (
                <span className="badge bg-green-50 text-green-700">Remote</span>
              )}

              {/* Job Type */}
              <span className={`badge ${typeInfo.color}`}>{typeInfo.label}</span>

              {/* Salary */}
              {job.salary && (
                <span className="flex items-center gap-1 text-slate-500">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z" fill="currentColor"/>
                  </svg>
                  {job.salary}
                </span>
              )}
            </div>

            {/* Tags */}
            {job.tags?.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {job.tags.slice(0, 4).map((tag, i) => (
                  <span key={i} className="badge bg-slate-100 text-slate-600 text-xs">{tag}</span>
                ))}
              </div>
            )}

            {/* Footer */}
            <div className="mt-3 flex items-center justify-between">
              <span className="text-xs text-slate-400">{timeAgo}</span>
              <span className="text-xs text-brand-500 font-medium group-hover:underline">
                View Job →
              </span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  )
}
