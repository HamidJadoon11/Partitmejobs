import Link from 'next/link'
import { CATEGORIES } from '../lib/fetchJobs'

export default function Footer() {
  const catLinks = CATEGORIES.slice(0, 8).map(cat => ({
    label: cat,
    href: `/category/${cat.toLowerCase().replace(/\s+&\s+/g, '-').replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')}`,
  }))

  return (
    <footer className="bg-navy-800 text-slate-400 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="font-display font-bold text-white text-xl">
              aParttime<span className="text-brand-400">Jobs</span>
            </Link>
            <p className="mt-3 text-sm leading-relaxed">
              Find the best remote part-time jobs. Updated every hour with fresh opportunities worldwide.
            </p>
            <div className="mt-4 flex items-center gap-2 text-xs">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              <span className="text-green-400">Live — Updated hourly</span>
            </div>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">Job Categories</h4>
            <ul className="space-y-2 text-sm">
              {catLinks.slice(0, 4).map(link => (
                <li key={link.href}>
                  <Link href={link.href} className="hover:text-white transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold text-sm mb-4 mt-6 md:mt-0">&nbsp;</h4>
            <ul className="space-y-2 text-sm">
              {catLinks.slice(4, 8).map(link => (
                <li key={link.href}>
                  <Link href={link.href} className="hover:text-white transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/" className="hover:text-white transition-colors">Home</Link></li>
              <li><Link href="/search" className="hover:text-white transition-colors">All Jobs</Link></li>
              <li><Link href="/search?type=part_time" className="hover:text-white transition-colors">Part-time</Link></li>
              <li><Link href="/search?type=contract" className="hover:text-white transition-colors">Contract</Link></li>
              <li><Link href="/search?type=freelance" className="hover:text-white transition-colors">Freelance</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-navy-700 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs">
          <p>© {new Date().getFullYear()} aParttimeJobs.us — All rights reserved.</p>
          <p>Remote jobs updated automatically every hour</p>
        </div>
      </div>
    </footer>
  )
}
