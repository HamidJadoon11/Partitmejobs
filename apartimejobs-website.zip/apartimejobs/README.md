# aParttimeJobs.us — Complete Setup Guide
## Remote Jobs Website (Auto-updated every hour)

---

## STEP 1 — Install Node.js on your computer

Go to https://nodejs.org → Download "LTS" version → Install it.
Open Terminal (Mac) or Command Prompt (Windows) and run:
```
node --version
```
You should see v18 or higher. ✅

---

## STEP 2 — Download this project

If you got this as a ZIP: Extract it to your Desktop.
Or if using Git:
```bash
git clone YOUR_REPO_URL
cd apartimejobs
```

---

## STEP 3 — Install dependencies

Open Terminal/CMD inside the project folder and run:
```bash
npm install
```
Wait 2-3 minutes. ✅

---

## STEP 4 — Set up your API Keys

### 4a. MongoDB Atlas (Database)
1. Go to https://cloud.mongodb.com
2. Create free account → Create free cluster (M0)
3. Click "Connect" → "Drivers" → Copy the connection string
4. It looks like: `mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/`
5. Replace `<password>` with your actual password

### 4b. RapidAPI / JSearch (Optional but recommended)
1. Go to https://rapidapi.com
2. Search "JSearch" → Subscribe to free plan
3. Copy your API Key from the header examples

### 4c. Adzuna (Optional)
1. Go to https://developer.adzuna.com
2. Register → Get App ID and App Key

---

## STEP 5 — Create your .env.local file

Copy `.env.local.example` to `.env.local`:
```bash
cp .env.local.example .env.local
```

Open `.env.local` in any text editor (Notepad/TextEdit) and fill in:
```
MONGODB_URI=mongodb+srv://YOUR_USER:YOUR_PASS@cluster0.xxxxx.mongodb.net/apartimejobs
RAPIDAPI_KEY=your_key_here          # Optional
ADZUNA_APP_ID=your_id_here          # Optional
ADZUNA_APP_KEY=your_key_here        # Optional
ADMIN_PASSWORD=MyStrongPassword123!  # Change this!
ADMIN_SECRET=randomstring32charslong # Make it random
NEXT_PUBLIC_SITE_URL=https://www.apartimejobs.us
CRON_SECRET=another_random_secret   # Make it random
```

---

## STEP 6 — Test locally

```bash
npm run dev
```
Open http://localhost:3000 in your browser. You should see the website! ✅

To fetch jobs for the first time, run in your browser:
```
http://localhost:3000/api/fetch-jobs?secret=YOUR_CRON_SECRET
```

---

## STEP 7 — Push to GitHub

### If you haven't set up GitHub yet:
1. Go to https://github.com → Login
2. Click "+" → "New repository"
3. Name it: `apartimejobs`
4. Click "Create repository"

### Push your code:
```bash
git init
git add .
git commit -m "Initial commit — aParttimeJobs.us"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/apartimejobs.git
git push -u origin main
```

---

## STEP 8 — Deploy on Vercel (FREE)

1. Go to https://vercel.com → Login with GitHub
2. Click "Add New" → "Project"
3. Find your `apartimejobs` repository → Click "Import"
4. **IMPORTANT** — Add Environment Variables:
   - Click "Environment Variables"
   - Add each variable from your `.env.local` file one by one:
     - `MONGODB_URI` → your MongoDB connection string
     - `ADMIN_PASSWORD` → your password
     - `ADMIN_SECRET` → your secret
     - `NEXT_PUBLIC_SITE_URL` → https://www.apartimejobs.us
     - `CRON_SECRET` → your cron secret
     - `RAPIDAPI_KEY` → your key (if you have it)
5. Click "Deploy" → Wait 2-3 minutes ✅

Your site is now live at a `.vercel.app` URL!

---

## STEP 9 — Connect your domain aParttimejobs.us

1. In Vercel: Go to your project → Settings → Domains
2. Type `apartimejobs.us` → Add
3. Also add `www.apartimejobs.us` → Add
4. Vercel shows you DNS records like:
   ```
   Type: A
   Name: @
   Value: 76.76.21.21
   ```
5. Go to WHERE YOU BOUGHT YOUR DOMAIN (Namecheap/GoDaddy etc.)
6. Find "DNS Settings" or "Manage DNS"
7. Add the A Record that Vercel gave you
8. Wait up to 24 hours → Your domain is connected! ✅

---

## STEP 10 — Set up Automatic Job Fetching (CRON)

This makes jobs update EVERY HOUR automatically for FREE.

1. Go to https://cron-job.org → Create free account
2. Click "Create cronjob"
3. URL: `https://www.apartimejobs.us/api/fetch-jobs?secret=YOUR_CRON_SECRET`
4. Schedule: Every 60 minutes
5. Add custom header:
   - Header name: `x-cron-secret`
   - Header value: `YOUR_CRON_SECRET` (same as in .env.local)
6. Save ✅

Jobs will now automatically update every hour!

---

## STEP 11 — Admin Panel

Go to: `https://www.apartimejobs.us/admin`
Enter your `ADMIN_PASSWORD` → You're in!

### What you can do in admin:
- **Dashboard** → See all stats, trigger manual job fetch
- **Jobs** → View all jobs, edit, delete, toggle active/featured
- **Add Job** → Manually add a job with custom details
- **Featured jobs** → Mark any job as featured (shows on homepage)

---

## STEP 12 — Google Search Console (SEO)

1. Go to https://search.google.com/search-console
2. Add property → Domain → `apartimejobs.us`
3. Verify ownership (Vercel/DNS method)
4. Submit sitemap: `https://www.apartimejobs.us/api/sitemap`
5. Google starts indexing your jobs! ✅

---

## PAGES ON YOUR WEBSITE

| URL | Page |
|-----|------|
| `/` | Homepage with latest + featured jobs |
| `/search` | Search all jobs with filters |
| `/jobs/[slug]` | Individual job detail page |
| `/category/software-development` | Category page |
| `/category/design-creative` | Design jobs |
| `/category/marketing-seo` | Marketing jobs |
| `/admin` | Admin login |
| `/admin/dashboard` | Admin dashboard |
| `/admin/jobs` | Manage all jobs |
| `/admin/add-job` | Add job manually |
| `/api/fetch-jobs` | Cron endpoint (protected) |
| `/api/sitemap` | Auto-generated sitemap |

---

## MAKING MONEY

### Google AdSense
- Wait until you have 100+ jobs and some daily visitors
- Apply at https://adsense.google.com
- Takes 2-4 weeks to approve
- Add your AdSense code to `components/Layout.js` in the `<Head>` section

### Featured Listings
- In admin, mark any job as "Featured" → it appears at the top of homepage
- You can charge employers to feature their jobs

---

## NEED HELP?

If something doesn't work:
1. Check that all `.env.local` variables are filled correctly
2. Make sure MongoDB Atlas IP Whitelist includes `0.0.0.0/0` (allow all)
3. Check Vercel logs: Vercel Dashboard → Your Project → Functions tab

---

Built with Next.js, MongoDB, Tailwind CSS — Deployed on Vercel
